# Google Genai Lambda Layer
# This layer provides google-genai and its dependencies for Lambda functions